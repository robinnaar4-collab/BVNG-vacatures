# BVNG Vacature Signalering

Dagelijkse signalering van vaste functies in management en beleid bij Nederlandse gemeenten.

## Wat dit is

Een lichtgewicht systeem dat elke ochtend om 07:30 publieke gemeentelijke vacatures verzamelt, filtert op BVNG criteria (vast dienstverband, management of beleid), en presenteert in een webdashboard. Draait gratis op GitHub Actions met GitHub Pages.

## Architectuur

```
scrapers/        Python modules die elk een bron afschrapen
  base.py        Gemeenschappelijke logica (rate limiting, requests)
  models.py      Vacature datamodel
  filters.py     BVNG specifieke filters
  database.py    SQLite opslag met deduplicatie
  werkenbijdeoverheid.py
  gemeentebanen.py

run.py           Orchestrator, wordt aangeroepen door GitHub Actions

dashboard/       Statisch HTML/CSS/JS dashboard
  index.html
  data.json      Wordt elke run vernieuwd

data/            SQLite database (in git, voor historie)
  vacatures.db

.github/workflows/
  dagelijkse-scrape.yml
```

## Lokaal draaien

```bash
pip install -r requirements.txt
python run.py
```

Open dan `dashboard/index.html` in een browser. Op MacOS kun je
`open dashboard/index.html` doen, maar voor lokaal testen met JSON
laden via fetch werkt het beter om een lokale server te starten:

```bash
cd dashboard && python -m http.server 8000
```

Open dan http://localhost:8000

## Test zonder echte scrapers

```bash
python test_flow.py
```

Dit toont met dummy data hoe de filter en database werken,
zonder een echte website aan te raken.

## Op GitHub deployen

1. Maak een nieuwe GitHub repository, push deze code erheen.
2. Ga naar Settings, Pages, en kies bron: GitHub Actions.
3. Ga naar Actions tab, schakel workflows in.
4. Trigger de workflow handmatig (workflow_dispatch) of wacht tot 07:30.

Na de eerste succesvolle run zie je het dashboard op `https://<jouw-username>.github.io/<repo-naam>/`.

## Belangrijk: de scrapers afmaken

De huidige scraper modules zijn werkende skeletten, maar ze hebben de echte selectoren en API endpoints nog niet ingevuld. Dat moet je in jouw eigen omgeving doen, want vanuit een sandbox kun je de live sites niet inspecteren.

**Voor werkenbijdeoverheid.nl:**

1. Open https://www.werkenbijdeoverheid.nl/vacatures in Chrome.
2. Open DevTools (F12), tab Netwerk.
3. Filter op XHR/Fetch.
4. Refresh de pagina, kijk welke JSON endpoint wordt aangeroepen.
5. Open `scrapers/werkenbijdeoverheid.py` en vul de juiste URL en payload in.

**Voor gemeentebanen.nl:**

1. Open https://www.gemeentebanen.nl/vacatures.
2. Bekijk de HTML bron (rechtermuisklik, Paginabron weergeven).
3. Zoek naar de container classes voor elke vacature.
4. Pas de selectoren in `scrapers/gemeentebanen.py` aan.

## Scrapers toevoegen

Om een nieuwe bron toe te voegen, maak een nieuw bestand in `scrapers/`:

```python
from .base import BaseScraper
from .models import Vacature

class MijnNieuweScraper(BaseScraper):
    naam = "mijn_bron"
    base_url = "https://example.com"

    def scrape(self):
        # Doe je werk, yield Vacature objecten
        response = self.fetch(f"{self.base_url}/vacatures")
        # ... parse ...
        yield Vacature(titel=..., gemeente=..., url=..., bron=self.naam)
```

Voeg de klasse toe aan `SCRAPER_KLASSEN` in `run.py`. Klaar.

Goede kandidaten om toe te voegen:

- ATS specifieke scrapers (Easycruit, Carerix, Recruitee, Otys) die meerdere gemeenten in één keer dekken.
- W&S bureaus zoals PublicSpirit, Castanho, Zeelenberg (let op gebruiksvoorwaarden).
- Werkenbijdeoverheid sub-feeds per gemeente.

## Filters aanpassen

In `scrapers/filters.py` staan de woordenlijsten voor management en beleidsfuncties. Pas die aan om strenger of breder te filteren. Bijvoorbeeld om griffieposities expliciet mee te nemen, voeg "griffier" toe aan `MANAGEMENT_TREFWOORDEN`.

## Beleefdheid en juridisch

De scrapers houden zich aan beleefde scraping principes:

- 1 seconde wachten tussen requests.
- User Agent identificeert de scraper.
- Alleen publieke pagina's, geen accounts of inloggen.
- Honoreer eventuele robots.txt indien aanwezig.

Dit zijn publieke vacaturepagina's die bedoeld zijn om door zoekmachines geconsumeerd te worden. Voor commerciële platforms (Flextender, Magnit) gelden andere regels en die hebben we hier expliciet niet opgenomen.

## Mogelijke volgende stappen

1. **Notificaties.** Voeg een Slack of e-mail notificatie toe in `run.py` voor nieuwe vacatures.
2. **Migratie naar Supabase.** Vervang de SQLite door PostgreSQL voor meerdere gebruikers.
3. **Koppeling met kandidatenbestand.** Match elke nieuwe vacature met je LinkedIn netwerk export.
4. **Latente vraag voorspelling.** Vergelijk vacaturepatronen met begrotingscyclus en coalitieakkoorden voor early signals.
5. **W&S bureaus.** Voeg scrapers toe voor PublicSpirit, Castanho, BMC en Zeelenberg.
