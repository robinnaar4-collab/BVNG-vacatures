"""
Hoofdorchestrator. Wordt aangeroepen door GitHub Actions.

Werkwijze:
  1. Run alle geconfigureerde scrapers.
  2. Pas filters toe (alleen vaste functies in management/beleid).
  3. Sla op in SQLite database met deduplicatie.
  4. Exporteer naar dashboard/data.json voor het statische dashboard.
"""
from datetime import datetime
import json
import logging
import sys
from pathlib import Path

from scrapers.database import VacatureDatabase
from scrapers.filters import filter_voor_bvng
from scrapers.gemeentebanen import GemeentebanenScraper
from scrapers.werkenbijdeoverheid import WerkenbijdeoverheidScraper


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("orchestrator")


SCRAPER_KLASSEN = [
    WerkenbijdeoverheidScraper,
    GemeentebanenScraper,
    # Voeg hier extra scrapers toe naarmate we ze ontwikkelen
]


def voer_alle_scrapers_uit(db: VacatureDatabase):
    bronnen = [klasse.naam for klasse in SCRAPER_KLASSEN]
    run_id = db.log_run_start(bronnen)

    alle_vacatures = []
    fouten = []

    for klasse in SCRAPER_KLASSEN:
        scraper = klasse()
        logger.info("Start scraper: %s", scraper.naam)
        try:
            voor_bron = list(scraper.scrape())
            logger.info("Bron %s leverde %d vacatures", scraper.naam, len(voor_bron))
            alle_vacatures.extend(voor_bron)
        except Exception as exc:
            logger.exception("Fout in scraper %s", scraper.naam)
            fouten.append(f"{scraper.naam}: {exc}")

    logger.info("Totaal verzameld: %d vacatures", len(alle_vacatures))

    # Filter op BVNG criteria
    relevant = filter_voor_bvng(alle_vacatures)
    logger.info("Na BVNG filter: %d relevante vacatures", len(relevant))

    # Sla op met deduplicatie
    nieuw_aantal = 0
    for vacature in relevant:
        if db.upsert_vacature(vacature):
            nieuw_aantal += 1

    logger.info("Nieuw deze run: %d", nieuw_aantal)

    db.markeer_verdwenen_als_inactief(max_leeftijd_dagen=14)
    db.log_run_einde(run_id, len(relevant), nieuw_aantal, fouten)

    return nieuw_aantal


def exporteer_naar_dashboard(db: VacatureDatabase, output_pad: Path):
    """Schrijf JSON voor het statische dashboard."""
    actief = db.haal_actieve_vacatures_op()
    nieuw_24h = {v["vacature_id"] for v in db.haal_nieuwe_vacatures_op(sinds_dagen=1)}
    nieuw_7d = {v["vacature_id"] for v in db.haal_nieuwe_vacatures_op(sinds_dagen=7)}

    for vacature in actief:
        if vacature["vacature_id"] in nieuw_24h:
            vacature["nieuw_label"] = "vandaag"
        elif vacature["vacature_id"] in nieuw_7d:
            vacature["nieuw_label"] = "deze_week"
        else:
            vacature["nieuw_label"] = "ouder"

    payload = {
        "gegenereerd_op": datetime.utcnow().isoformat(),
        "totaal_actief": len(actief),
        "nieuw_vandaag": len(nieuw_24h),
        "nieuw_deze_week": len(nieuw_7d),
        "vacatures": actief,
    }

    output_pad.parent.mkdir(parents=True, exist_ok=True)
    output_pad.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    logger.info("Dashboard data weggeschreven: %s (%d vacatures)",
                output_pad, len(actief))


def main():
    db_pad = Path("data/vacatures.db")
    dashboard_pad = Path("dashboard/data.json")

    db = VacatureDatabase(db_pad)
    nieuw_aantal = voer_alle_scrapers_uit(db)
    exporteer_naar_dashboard(db, dashboard_pad)

    logger.info("Klaar. Nieuw deze run: %d", nieuw_aantal)


if __name__ == "__main__":
    main()
