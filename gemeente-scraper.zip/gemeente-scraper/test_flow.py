"""
Test script: simuleer een scrape run met realistische dummy data
om de filter en database logica te valideren.

Run met: python test_flow.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from scrapers.models import Vacature
from scrapers.filters import filter_voor_bvng
from scrapers.database import VacatureDatabase
from run import exporteer_naar_dashboard


# Realistische dummy data, gebaseerd op typische gemeentelijke vacatures
dummy_vacatures = [
    Vacature(
        titel="Directeur Sociaal Domein",
        gemeente="Gemeente Dordrecht",
        url="https://werkenbijdordrecht.nl/vacature/directeur-sociaal-domein-123",
        bron="werkenbijdeoverheid",
        omschrijving="Wij zoeken een ervaren directeur voor het sociaal domein.",
        schaal="16",
        uren="36",
        contract_type="vast dienstverband",
        publicatie_datum="2026-05-10",
        sluiting_datum="2026-06-15",
        locatie="Dordrecht",
    ),
    Vacature(
        titel="Teamleider Wmo Voorzieningen",
        gemeente="Gemeente Vijfheerenlanden",
        url="https://werkenbijvijfheerenlanden.nl/vacature/teamleider-wmo-456",
        bron="werkenbijdeoverheid",
        omschrijving="Voor het team Wmo voorzieningen zoeken wij een teamleider.",
        schaal="13",
        uren="32-36",
        contract_type="vast dienstverband met uitzicht",
        publicatie_datum="2026-05-09",
    ),
    Vacature(
        titel="Senior Beleidsadviseur Ruimtelijke Ordening",
        gemeente="Gemeente Utrecht",
        url="https://werkenbijutrecht.nl/vacature/sr-beleidsadviseur-ro-789",
        bron="gemeentebanen",
        omschrijving="Senior rol op het gebied van RO en wonen.",
        schaal="12",
        contract_type="vast dienstverband",
        publicatie_datum="2026-05-11",
    ),
    # Deze moet eruit gefilterd worden: interim
    Vacature(
        titel="Interim Programmamanager Energietransitie",
        gemeente="Gemeente Amsterdam",
        url="https://werkenbijamsterdam.nl/vacature/interim-pm-energie-101",
        bron="gemeentebanen",
        omschrijving="Tijdelijke opdracht voor 12 maanden via detachering.",
        contract_type="tijdelijk",
    ),
    # Deze moet eruit gefilterd worden: uitvoerend niveau, geen management
    Vacature(
        titel="Medewerker Burgerzaken",
        gemeente="Gemeente Rotterdam",
        url="https://werkenbijrotterdam.nl/vacature/medewerker-burgerzaken-202",
        bron="werkenbijdeoverheid",
        contract_type="vast dienstverband",
        schaal="7",
    ),
    Vacature(
        titel="Afdelingshoofd Bedrijfsvoering",
        gemeente="Gemeente Groningen",
        url="https://werkenbijgroningen.nl/vacature/afdelingshoofd-bv-303",
        bron="werkenbijdeoverheid",
        omschrijving="Leidinggevende functie binnen bedrijfsvoering.",
        schaal="14",
        contract_type="vast dienstverband",
        publicatie_datum="2026-05-08",
    ),
    Vacature(
        titel="Strategisch Beleidsadviseur Bestuur",
        gemeente="Gemeente Den Haag",
        url="https://werkenbijdenhaag.nl/vacature/strat-beleidsadv-404",
        bron="gemeentebanen",
        contract_type="vast dienstverband",
        schaal="13",
        publicatie_datum="2026-05-07",
    ),
    # Deze moet eruit: stage
    Vacature(
        titel="Stagiair Beleidsadvies",
        gemeente="Gemeente Eindhoven",
        url="https://werkenbijeindhoven.nl/vacature/stagiair-505",
        bron="werkenbijdeoverheid",
        contract_type="stage",
    ),
]

print("=" * 60)
print("TEST: filter en database flow")
print("=" * 60)

print(f"\nInput: {len(dummy_vacatures)} ruwe vacatures")

# Pas filter toe
relevant = filter_voor_bvng(dummy_vacatures)
print(f"Na filter (vast en management/beleid): {len(relevant)} relevant")
print("\nGeselecteerde vacatures:")
for v in relevant:
    print(f"  [{v.functie_categorie:>15}]  {v.titel}  ({v.gemeente})")

print("\nUitgefilterd:")
geslecteerd_ids = {v.vacature_id for v in relevant}
for v in dummy_vacatures:
    if v.vacature_id not in geslecteerd_ids:
        print(f"  -  {v.titel}  ({v.gemeente})")

# Test database
print("\n" + "=" * 60)
print("Database test")
print("=" * 60)

test_db_pad = Path("/tmp/test_vacatures.db")
if test_db_pad.exists():
    test_db_pad.unlink()

db = VacatureDatabase(test_db_pad)

run_id = db.log_run_start(["werkenbijdeoverheid", "gemeentebanen"])
nieuw = 0
for v in relevant:
    if db.upsert_vacature(v):
        nieuw += 1
print(f"\nEerste run: {nieuw} nieuwe vacatures opgeslagen")
db.log_run_einde(run_id, len(relevant), nieuw, [])

# Tweede run: dezelfde vacatures
nieuw2 = 0
for v in relevant:
    if db.upsert_vacature(v):
        nieuw2 += 1
print(f"Tweede run met dezelfde data: {nieuw2} nieuw (zou 0 moeten zijn)")

# Test dashboard export
print("\n" + "=" * 60)
print("Dashboard export test")
print("=" * 60)

test_dashboard_pad = Path("/tmp/test_dashboard_data.json")
exporteer_naar_dashboard(db, test_dashboard_pad)

import json
with open(test_dashboard_pad) as f:
    payload = json.load(f)

print(f"\nDashboard JSON gegenereerd:")
print(f"  Totaal actief:    {payload['totaal_actief']}")
print(f"  Nieuw vandaag:    {payload['nieuw_vandaag']}")
print(f"  Nieuw deze week:  {payload['nieuw_deze_week']}")
print(f"  Eerste vacature:  {payload['vacatures'][0]['titel']}")

# Cleanup
test_db_pad.unlink()
test_dashboard_pad.unlink()

print("\n" + "=" * 60)
print("Alle tests geslaagd")
print("=" * 60)
